// {{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mrxp.rc
//
#define IDS_CONFIGSHEET_TITLE           1
#define IDS_INVALID_CONFIG_ERROR        2
#define IDS_ERROR_CAPTION               3
#define IDS_PROVIDER_DISPLAY            4
#define IDS_STATUS_OFFLINE              5
#define IDS_STATUS_AVAILABLE            6
#define IDS_STATUS_ONLINE               7
#define IDS_STATUS_UPLOADING            8
#define IDS_STATUS_DOWNLOADING          9
#define IDS_STATUS_INFLUSHING           10
#define IDS_STRING11                    11
#define IDS_STATUS_OUTFLUSHING          11
#define IDS_NDR_DEFAULT_TEXT            100
#define IDS_NDR_BAD_NETPATH             101
#define IDD_CONFIGPAGE                  102
#define IDC_LBL_DISPLAY_NAME            1000
#define IDC_EDIT_DISPLAY_NAME           1001
#define IDC_LBL_INBOX                   1002
#define IDC_EDIT_INBOX                  1003

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
